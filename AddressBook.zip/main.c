/*Name: Chaithra P
   Date: 07 December 2025
   Sample Input:
            Name: Aarav Menon
            Mobile_number:9098760032
            Mail_ID:aaravmenon24@gmail.com
    Sample Output:
            Contact saved successfully
            Total Contacts:1
    Description:
              1. create_contact(): Adds a new contact by taking user input, validating name/phone/email,
                 checking for duplicates, storing the contact in the list, updating the count, and saving the updated data to the file.
              2. search_contact(): Searches for a contact using a name, phone number, or email.
                 Performs a sequential scan and returns the index if found; otherwise returns –1.
                 Used by edit and delete functions.
              3. list_contacts(): Displays all saved contacts in an organized format.
                 Loops through the contact list and prints each contact’s details.
              4. edit_contact(): Allows updating of specific fields of a contact.
                 Finds the contact using search_contact(), takes new values, validates them, 
                 checks for duplicates, updates the record, and saves the modified list to the file.
              5. delete_contact(): Deletes a selected contact after searching and confirming.
                 Shifts remaining records to maintain structure, decreases the count, and saves the updated list to the file.
              6. save_contacts_to_file(): Writes all in-memory contact records to a file to ensure data persistence after program termination.
*/
#include <stdio.h>
#include "contact.h"
/* Structure declaration */

int main()
{
    /* Variable and structre defintion */
    int option;
    AddressBook addressbook;
    addressbook.contact_count = 0;

    // init_intitalization(&addressbook);
    load_contacts_from_file(&addressbook);

    while (1)
    {
        printf("\nAddress book menu\n"); /* Give a prompt message for a user */
        printf("1.Add contact\n2.search contact\n3.Edit contact\n4.Delete contact\n5.Display contact\n6.Save contact\n7.Exit\n");
        printf("Enter the option : ");
        scanf("%d", &option);
        getchar();

        switch (option) /* Based on choosed option */
        {
        case 1:
        {
            create_contact(&addressbook);
            break;
        }

        case 2:
        {
           // printf("Search Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4. Exit\nEnter the option : "); /* Providing menu */
            search_contacts(&addressbook);
            break;
        }
        case 3:
           // printf("Edit Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4.Exit\nEnter the option : "); /* Providing menu */

            edit_contact(&addressbook);
            break;

        case 4:
        {
           // printf("Delete Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4.Exit\nEnter the option : "); /* Providing menu */

            delete_contact(&addressbook);
            break;
        }
        case 5:
        {
            printf("List Contacts:\n");
            list_contacts(&addressbook);
            break;
        }

        case 6:
            printf("Saving contacts\n");
            save_contacts(&addressbook);
            break;

        case 7:
            printf("INFO : Save and Exit...\n");
            save_contacts(&addressbook);
            return 0;

        default:
            printf("Invalid option \n");
            break;
        }
    }
    return 0;
}