   /*Description:
              1. create_contact(): Adds a new contact by taking user input, validating name/phone/email,
                 checking for duplicates, storing the contact in the list, updating the count, and saving the updated data to the file.
              2. search_contact(): Searches for a contact using a name, phone number, or email.
                 Performs a sequential scan and returns the index if found; otherwise returns –1.
                 Used by edit and delete functions.
              3. list_contacts(): Displays all saved contacts in an organized format.
                 Loops through the contact list and prints each contact’s details.
              4. edit_contact(): Allows updating of specific fields of a contact.
                 Finds the contact using search_contact(), takes new values, validates them, 
                 checks for duplicates, updates the record, and saves the modified list to the file.
              5. delete_contact(): Deletes a selected contact after searching and confirming.
                 Shifts remaining records to maintain structure, decreases the count, and saves the updated list to the file.
              6. save_contacts_to_file(): Writes all in-memory contact records to a file to ensure data persistence after program termination.
   */
   #include <stdio.h>
    #include "contact.h"
    #include <string.h>
    #include<ctype.h>

    /* Function definitions */
    // void init_intitalization(AddressBook *addressbook)
    // {
    int multiple_name_found(AddressBook *addressbook,char *name);
    void save_contacts_to_file(AddressBook *addressbook);
    int is_duplicate(AddressBook *addressbook,int opt,const char *value,int skip_ind);
    int isvalid_Mail_ID(char *mail,AddressBook *addressbook,int skip_ind);
    int isvalid_Mobile_no(const char *mobile_no,AddressBook *addressbook,int skip_ind);
    int isvalid_Name(const char *name);
    int find_contact(AddressBook *addressbook,int opt,char * value);
    //}

    /*-------------CREATE CONTACT----------------*/
    int create_contact(AddressBook *addressbook)
    {
        int flag=1;
        //Continue adding contacts while:flag==1,(contact_count<100)preventing array overflow(max 100 contacts)
        while(flag && (addressbook->contact_count<100))
        {
            int i=addressbook->contact_count; //position to store index of new contact 
            printf("Enter the Name: ");
            scanf(" %[^\n]",addressbook->contact_details[i].Name);             
            //validate name until correct      
            while(!(isvalid_Name(addressbook->contact_details[i].Name)))
            {
                printf("\033[11;31mName should contain only Alphabets and spaces! Try Again.\033[0m\n");
                printf("Enter the Name: ");
                scanf(" %[^\n]",addressbook->contact_details[i].Name);              
            }
            printf("Enter the Mobile number : ");
            scanf(" %[^\n]",addressbook->contact_details[i].Mobile_number);         
            //Validate Mobile number
            while(!(isvalid_Mobile_no(addressbook->contact_details[i].Mobile_number,addressbook,-1)))
            {
                printf("Enter the Mobile number : ");
                scanf(" %[^\n]",addressbook->contact_details[i].Mobile_number);              
            }
            printf("Enter the Mail_ID : ");
            scanf(" %[^\n]",addressbook->contact_details[i].Mail_ID);           
            //Validate Mail ID
            while(!(isvalid_Mail_ID(addressbook->contact_details[i].Mail_ID,addressbook,-1)))
            {
                printf("Enter the Mail_ID : ");
                scanf(" %[^\n]",addressbook->contact_details[i].Mail_ID);              
            }
            addressbook->contact_count++;//Increase total contact count
            printf("Do you want to continue[1-Yes][0-No]: ");
            int opt;
            scanf("%d",&opt);
            getchar();
            if(opt==1)
            {
                flag=1;//Continue if user selects 1
            }
            else
            {
            flag=0;
            }
        }
        //Display success message
        printf("\033[1;32mAddress count: %d\033[0m\n",addressbook->contact_count);
        printf("\033[1;32mContact Added Succesfully.\033[0m\n");
        return 0;
    }

/*------------LIST OF CONTACTS--------------*/
    void list_contacts(AddressBook *addressbook)
    {
        if(addressbook->contact_count>0)
        {
            printf("----------------------------List of contacts--------------------------------------\n");
            printf("Sl no.     Name                 Mobile number            Email_ID                  \n");
            printf("-----------------------------------------------------------------------------------\n");
            //Print all stored contacts
            for(int i=0;i<addressbook->contact_count;i++)
            {
                printf("%-10d",i+1);//Serial number
                printf("%-20s",addressbook->contact_details[i].Name);//Name
                printf("%-25s",addressbook->contact_details[i].Mobile_number);//Mobile number
                printf("%-40s\n",addressbook->contact_details[i].Mail_ID);//Mail_ID
            }
            printf("-----------------------------------------------------------------------------------\n");
        }
        else
        {
            printf("\033[1;31mNo contact found.\033[0m\n");//No contacts presents
        }
    }

    /*------------SEARCH CONTACTS------------*/
    int search_contacts(AddressBook *addressbook)
    {
        int opt;
        int i;
        char value[50];
        int flag=1;
        while(flag)
        {
            printf("Search by:\n1.Name\n2.Mobile_no.\n3.Mail_id\n4.Exit\nEnter the option: ");
            scanf("%d",&opt);
            getchar();  
        if(opt==1)
        {
            printf("Enter the Name: ");
            scanf(" %[^\n]",value);           
            i=multiple_name_found(addressbook,value);//Handles duplicates
        }
        else if(opt==2)
        {
            printf("Enter the Mobile number : ");
            scanf(" %[^\n]",value);        
            i=find_contact(addressbook,opt,value);//Search by Mobile number
        }                  
        else if(opt==3)
        {
            printf("Enter the Mail_ID:");
            scanf(" %[^\n]",value);       
            i=find_contact(addressbook,opt,value);//serach by mail
        } 
        else if(opt==4)
        {
            return 0;
        }               
        else
        {
            printf("\033[1;31mInvalid option,Enter between 1 to 4\033[0m\n");
            continue;
        }
        if(i==-1)
        {
            printf("\033[1;31mContact not found\033[0m\n");
            continue;
        }
        else
        {
            printf("\033[1;32mContact found\033[0m\n");
            printf("Name:%s\n",addressbook->contact_details[i].Name);
            printf("Mobile_number:%s\n",addressbook->contact_details[i].Mobile_number);
            printf("Mail_ID:%s\n",addressbook->contact_details[i].Mail_ID);
        }   
         printf("Do you want to continue[1-Yes][0-No]: ");
            int opt;
            scanf("%d",&opt);
            getchar();
            if(opt==1)
            {
                flag=1;
            }
            else
            {
            flag=0;
            }
        }                     
        return 0;
    }

    /*--------EDIT CONTACT------------*/
    int edit_contact(AddressBook *addressbook)
    {
        int flag=1;
        int opt;
        while(flag)
        {  
            printf("Edit Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4.Exit\nEnter the option : ");
            scanf("%d", &opt);
            getchar();
            int i;
            char value[50];
            if (opt == 1)//Find contact to edit
            {
                printf("Enter the Name: ");
                scanf(" %[^\n]", value);
                i=multiple_name_found(addressbook,value);
            }
            else if (opt == 2)
            {
                printf("Enter the Mobile number: ");
                scanf(" %[^\n]", value);
                i=find_contact(addressbook,opt,value);
            }
            else if (opt == 3)
            {
                printf("Enter the Mail_ID: ");
                scanf(" %[^\n]", value);
                i=find_contact(addressbook,opt,value);
            }
            else if (opt == 4)
            {
                return 0;
            }           
            else
            {
                printf("\033[1;31mInvalid option,Enter the option between 1 to 4\033[0m\n");
                continue;
            }
            if (i == -1)//If contact not returns -1
            {
                printf("\n\033[1;31mContact not found\033[0m\n");
                continue;
            }
            printf("\n\033[1;32mContact found\033[0m\n");
            printf("Name: %s\n",addressbook->contact_details[i].Name);
            printf("Mobile_number.: %s\n",addressbook->contact_details[i].Mobile_number);
            printf("Mail_ID: %s\n",addressbook->contact_details[i].Mail_ID);

            //choose what to edit
            int editopt;
            printf("What do you want to Edit:\n1.Name\n2.Mobile_no.\n3.Mail_id\n4.Edit all\n5.Exit\nEnter the option to edit: ");
            scanf("%d", &editopt);
            getchar();
            if (editopt == 1)
            {
                printf("Enter the new Name : ");
                scanf(" %[^\n]", addressbook->contact_details[i].Name);
                 while(!(isvalid_Name(addressbook->contact_details[i].Name)))//Validate new name
                {
                   printf("\033[1;31mName should contain only Alphabets and spaces! Try Again.\033[0m\n");
                   printf("Enter the Name: ");
                   scanf(" %[^\n]",addressbook->contact_details[i].Name);
                }
            }
            else if (editopt == 2)
            {
                printf("Enter the new Mobile number: ");
                scanf(" %[^\n]", addressbook->contact_details[i].Mobile_number);
                while(!(isvalid_Mobile_no(addressbook->contact_details[i].Mobile_number,addressbook,i)))//Validate new mobile number
                {
                  printf("Enter the new Mobile number : ");
                  scanf(" %[^\n]",addressbook->contact_details[i].Mobile_number);
                }
            }
            else if (editopt == 3)
            {
                printf("Enter the New Mail_ID: ");
                scanf(" %[^\n]", addressbook->contact_details[i].Mail_ID);
                while(!(isvalid_Mail_ID(addressbook->contact_details[i].Mail_ID,addressbook,i)))//Validate new Mail_id
                {
                  printf("Enter the Mail ID : ");
                  scanf(" %[^\n]",addressbook->contact_details[i].Mail_ID); 
                }
            }
            else if(editopt == 4)
            {
                printf("Enter the New Name : ");
                scanf(" %[^\n]", addressbook->contact_details[i].Name);
                 while(!(isvalid_Name(addressbook->contact_details[i].Name)))
                {
                   printf("\033[1;31mName should contain only Alphabets and spaces! Try Again.\033[0m\n");
                   printf("Enter the Name: ");
                   scanf(" %[^\n]",addressbook->contact_details[i].Name);
                }
                printf("Enter the new Mobile number: ");
                scanf(" %[^\n]", addressbook->contact_details[i].Mobile_number);
                while(!(isvalid_Mobile_no(addressbook->contact_details[i].Mobile_number,addressbook,i)))
                {
                  printf("Enter the new Mobile number : ");
                  scanf(" %[^\n]",addressbook->contact_details[i].Mobile_number);
                }
                 printf("Enter the new Mail_ID: ");
                scanf(" %[^\n]", addressbook->contact_details[i].Mail_ID);
                while(!(isvalid_Mail_ID(addressbook->contact_details[i].Mail_ID,addressbook,i)))
                {
                  printf("Enter the Mmail ID : ");
                  scanf(" %[^\n]",addressbook->contact_details[i].Mail_ID);
                }               
            }
            else if (editopt == 5)
            {
                return 0; 
            }
            else
            {
                printf("\033[1;31mInvalid edit option, Enter between 1 to 5\033[0m\n");
                continue;
            }
            printf("\033[1;33mConctact Edited Succesfully\033[0m\n");
             printf("Do you want to continue[1-Yes][0-No]: ");
            int opt;
            scanf("%d",&opt);
            getchar();
            if(opt==1)
            {
                flag=1;
            }
            else
            {
            flag=0;
            }
        }
        return 0;
    }

    /*------------DELETE CONTACT------------*/
    int delete_contact(AddressBook *addressbook)
    {
        int flag=1;
        int opt;
        int i;
        while(flag)
        {
            //Finding contact to delete
            printf("Delete Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4.Exit\nEnter the option : ");
            scanf("%d", &opt);
            getchar();       
            char value[50];
            if (opt == 1)
            {
                printf("Enter the Name: ");
                scanf(" %[^\n]", value);
                i=multiple_name_found(addressbook,value);
            }
            else if (opt == 2)
            {
                printf("Enter the Mobile number: ");
                scanf(" %[^\n]", value);
                i=find_contact(addressbook,opt,value);
            }
            else if (opt == 3)
            {
                printf("Enter the Mail_ID: ");
                scanf(" %[^\n]", value);
                i=find_contact(addressbook,opt,value);
            }
            else if (opt == 4)
            {
                return 0;
            }            
            else
            {
                printf("\033[1;31mInvalid option,Enter between 1 to 4\033[0m\n");
                continue;
            }
            if (i == -1)//If contact not found returns -1
            {
                printf("\n\033[1;31mContact not found\033[0m\n");
                continue;
            }
            printf("\n\033[1;32mContact found\033[0m\n");
            printf("Name: %s\n",addressbook->contact_details[i].Name);
            printf("Mobile_no.: %s\n",addressbook->contact_details[i].Mobile_number);
            printf("Mail_ID: %s\n",addressbook->contact_details[i].Mail_ID);
            printf("Do you want to delete [1-Yes][0-N0]: ");
            int k;
            scanf("%d",&k);
            getchar();
            if(k==0)
            {
                return 0;
            }
            //Shift all the elements from left to fill the deleted gap
            for(int j=i;j<addressbook->contact_count-1;j++)// i is the contact to be deleted, so to the place of i next will be shifted
            {
                strcpy(addressbook->contact_details[j].Name,addressbook->contact_details[j+1].Name);
                strcpy(addressbook->contact_details[j].Mobile_number,addressbook->contact_details[j+1].Mobile_number);
                strcpy(addressbook->contact_details[j].Mail_ID,addressbook->contact_details[j+1].Mail_ID);
            }
            addressbook->contact_count--;//Decrement the count after deletion
            printf("Total Contacts: %d\n",addressbook->contact_count);
            printf("Do you want to continue[1-Yes][0-No]: ");
            scanf("%d",&opt);
            getchar();
            if(opt==1)
            {
                flag=1;
            }
            else
            {
            flag=0;
            }
        }
        return 0;
    }

    /*------------SAVE CONTACT------------*/
    int save_contacts(AddressBook *addressbook)
    {
        save_contacts_to_file(addressbook);
        return 0;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
    }

    /*--------FIND CONTACT------------*/
    int find_contact(AddressBook *addressbook,int opt,char *value)
    {
        for(int i=0;i<addressbook->contact_count;i++)
        {
            if(opt==1 && strcmp(addressbook->contact_details[i].Name,value)==0)
            return i;//If found retur the index of the element
            if(opt==2 && strcmp(addressbook->contact_details[i].Mobile_number,value)==0)
            return i;
            if(opt==3 && strcmp(addressbook->contact_details[i].Mail_ID,value)==0)
            return i;
        }
        return -1;//If contact not found
    }

    /*------------NAME VALIDATION------------*/
    int isvalid_Name(const char *name)
    {
        for(int i=0;name[i]!='\0';i++)
        {
            char ch=name[i];
            if(!((isalpha(ch)) || (isspace(ch))))//check the character is not alphabet or space
            {
                return 0;
            }
        }
        return 1;//If all validation passes returns 1
    }

    /*------------MOBILE NUMBER VALIDATION------------*/
    int isvalid_Mobile_no(const char *mobile_no,AddressBook *addressbook,int skip_ind)
    {
        int count=0;
        for(int i=0;mobile_no[i]!='\0';i++)//Only digits allowed
        {
          if(!(isdigit(mobile_no[i])))
          {
            printf("\033[1;31mMobile number should contain only digits! Try again.\033[0m\n");
            return 0;
          }
          count++;
        }
        if(count<10)
        {
            printf("\033[1;31mMobile number must have 10 digits! Try again.\033[0m\n");
            return 0;
        }
        if(count>10)
        {
            printf("\033[1;31mMobile number should only have 10 digits! Try again.\033[0m\n");
            return 0;
        }
        if(mobile_no[0]<'6' || mobile_no[0]>'9')
        {
            printf("\033[1;31mMobile number should start with digits between 6 and 9!\033[0m\n");
            return 0;
        }
        if(is_duplicate(addressbook,2,mobile_no,skip_ind))//checks dupliacte Mobile no
        {
            printf("\033[1;31mMobile number already Exist! Try again.\033[0m\n"); 
            return 0;
        }
        return 1;//If all conditions pass then returns 1
    }

    /*------------MAIL ID VALIDATION-------------*/
    int isvalid_Mail_ID(char * mail,AddressBook *addressbook,int skip_ind)
    {
      int len=strlen(mail);
      int ind=0;
      if(!(islower(mail[0])))
      {
        printf("\033[1;31mMail ID should start with lowercase letters.\033[0m\n");
        return 0;
      }
      if(len<5 || (strcmp(".com",mail+len-4)!=0))
      {
        printf("\033[1;31mMail ID should end with .com\033[0m\n");
        return 0;
      }
      for(int i=0;i<len;i++)//Check the allowed characters
      {
        if(!( isalpha(mail[i]) ||  isdigit(mail[i]) || mail[i]=='@' || mail[i]=='.'))
        {
            printf("\033[1;31mSpecial character are not allowed in mail id expect @ and .\033[0m\n");
            return 0;
        }
      }
      int flag=0;
      char ch;
      for(int i=0;i<len;i++)
      {
        ch=mail[i];
        if(isupper(ch))
        {
            printf("\033[1;31mUpper case letters are not allowed in Mail ID\033[0m\n");
            return 0;
        }
        if(ch=='@')//Checks the use of @ symbol
        {
            if(flag==1)
            {
               printf("\033[1;31mMail id should only have one @ symbol\033[0m\n");
               return 0;
            }
            flag=1;
            ind=i;
        }
      }
      if(flag==0)
      {
        printf("\033[1;31mMail id  must contain @ symbol\033[0m\n");   
        return 0;
      }
      if(ind<4)
      {
        printf("\033[1;31mMail id must atleast have 4 characters before @ symbol.\033[0m\n");
        return 0;
      }
      int x=(len-4)-(ind+1);//ind is the index of @ symbol found len is the length of mail id
      if(x<1)
      {
        printf("\033[1;31mMail id must have atleast one character between @ and .com.\033[0m\n");
        return 0;
      }
      if(is_duplicate(addressbook,3,mail,skip_ind))//Checks dupliccate mail id
      {
       printf("\033[1;31mMail id already Exist! Try again.\033[0m\n"); 
       return 0;
      }
      return 1;//returns 1 if all condition passes
    }

    /*------------DUPLICATE MOBILE NUMBER ANDC MAIL ID CHECK------------*/
    int is_duplicate(AddressBook *addressbook,int opt,const char * value,int skip_ind)
    {
        for(int i=0;i<addressbook->contact_count;i++)
        {
            if(i==skip_ind)
             continue;
            if(opt==2 && (strcmp(addressbook->contact_details[i].Mobile_number,value)==0))
             return 1;
            if(opt==3 && (strcmp(addressbook->contact_details[i].Mail_ID,value)==0))
             return 1; 
        }
        return 0;//if not true
    }

    /*------------SAVE CONTACTS TO FILE------------*/
    void save_contacts_to_file(AddressBook *addressbook)
    {
        FILE * fptr=fopen("contacts.txt","w");
        if(fptr==NULL)
        {
            printf("File is not found\n");
            return;
        }
        fprintf(fptr,"#%d\n",addressbook->contact_count);//First line store number of contact
        for(int i=0;i<addressbook->contact_count;i++)//Write each contact as Name,Mobile number,Mail_Id
        {
            fprintf(fptr,"%s,%s,%s\n",addressbook->contact_details[i].Name,addressbook->contact_details[i].Mobile_number,addressbook->contact_details[i].Mail_ID);
        }
        fclose(fptr);
    }

    /*-----------LOAD CONTACT FROM FILE-------------*/
    void load_contacts_from_file(AddressBook *addressbook)
    {
        FILE *fptr=fopen("contacts.txt","r");
        {
            if(fptr==NULL)
            {
                fptr=fopen("contacts.txt","w");//Create the file if not exists
                fprintf(fptr,"#0\n");
                fclose(fptr);
                fptr=fopen("contacts.txt","r");
            }
            fscanf(fptr,"#%d\n",&addressbook->contact_count);//Read number of contacts
            for(int i=0;i<addressbook->contact_count;i++)//Read each element
            {
                fscanf(fptr,"%[^,], %[^,], %[^\n]\n",addressbook->contact_details[i].Name, addressbook->contact_details[i].Mobile_number, addressbook->contact_details[i].Mail_ID);
            }
        }
        fclose(fptr);
    }

    /*------------MULTIPLE NAME HANDLING------------*/
    int multiple_name_found(AddressBook*addressbook,char *name)
    {
        int arr[20];
        int count=0;
        for(int i=0;i<addressbook->contact_count;i++)//collect the index of matching name
        {
            if(strcmp(addressbook->contact_details[i].Name,name)==0)
            {
                arr[count]=i;
                count++;
            }
        }
        if(count==0)
        {
            //printf("\033[1;31mcontact not found.\033[0m\n");
            return -1;
        }
        if(count==1)//if only one match exits,return its index
        {
            return arr[0]; 
        }
        printf("\033[1;31mMultiple contacts found with name %s.\033[0m\n",name);
        for(int i=0;i<count;i++)
        {
            int j=arr[i];
            printf("%d\t\t%s\t\t%s\t\t%s\n",i+1,addressbook->contact_details[j].Name,addressbook->contact_details[j].Mobile_number,addressbook->contact_details[j].Mail_ID);
        }
        printf("Search by:\n1.Mobile no.\n2.Email id\nEnter the option:");
        int opt;
        scanf("%d",&opt);
        getchar();
        char value[50];
        if(opt==1)
        {
            printf("Enter the Mobile number: ");
            scanf(" %[^\n]",value);
        }
        else if(opt==2)
        {
            printf("Enter the Mail id: ");
            scanf(" %[^\n]",value);
        }
        else
        {
            printf("\033[1;31mInvalid option, Enter 1 or 2\033[0m");
            return -1;
        }
        for(int i=0;i<count;i++)//among the duplicates find the match of the entered option
        {
            int k=arr[i];
            if((strcmp(addressbook->contact_details[k].Mobile_number,value)==0) || 
                (strcmp(addressbook->contact_details[k].Mail_ID,value)==0))
            {
                return k;
            }
        }
        printf("\033[1;31mNo matching found.\033[0m\n");
        return -1;
    }